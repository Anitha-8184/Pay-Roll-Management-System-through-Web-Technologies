<?php
$grosspay="";
$taxablepay="";
$pensionablepay ="";
$studentloan =""; 
$nipayment ="";
$deduction ="";
$netpay ="";
$innercity ="";
$basicsalary ="";
$overtime ="";
$referenceno ="";
$employer  ="";
$empaddress  ="";
$taxperiod ="";
$pension =""; 
$tax ="";
$paydate ="";
$studentref ="";
$employee ="";
$postcode ="";
$address ="";
$taxcode ="";


extract($_POST);


if(isset($add))
{
	
$grosspay= $basicsalary + $overtime;
$taxablepay = ($grosspay * 9) /100; 
$pensionablepay = ($grosspay * 5.5) /100; 
$nipayment = ($grosspay * 2.5) /100;
$deduction=$taxablepay +  $pensionablepay + $nipayment; 
$netpay = $grosspay - $deduction ;
$basicsalary = $basicsalary ;

$paydate = date('d/m/y');

}	
?>

<!--===========================================================================================================-->

<HTML>
<HEAD>
<TITLE>Payroll Management System</TITLE>
<link rel="stylesheet" type="text/css" href="print.css" media="print">

<style type="text/css">

.style1 {	
	border-width: 0;
	border: solid gray 0px;
	width: 90%;
	border-radius: 5px;
	margin: 5px auto;
	background: white;
	

}

.style2 {
	border-width: 0;
	border: solid gray 0px;
	width: 90%;
	border-radius: 5px;
	margin: 5px auto;
	background: silver;
    font-size:20;
	
	
}
.tablefont
{
	font-size:16;
}

.btn {
  width: 302px;
  height: 50px;
  padding: 5px;
  background:	#00bfff;
  font-size:30px;
  color: white;
}
.cbtn{
	width:50px; 
	height:30px; 
	font-size:25; 
	border-radius:8px
	
}
#left
{
	position:absolute;
	left:0;
	width:50%;
}
#btn1:hover{
	
            border:3px solid #800080;
        
}

</style>
<!--===========================================================================================================-->



<!--===========================================================================================================-->

</HEAD>

<BODY bgcolor="lightblue">
<center>
<B><font color="white" style ="font-size:60" > PAYSLIP OF EMPLOYEE </font></B>
</center>
<hr size=5 color = "white">
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">


<!--==================================================================================================================-->
<table class="style1" > 
	
	<center id="left">
     <tr>
	<td>Payslip ToDate:</td>
		<td><input type="text" name = "pension" style="width: 400px" placeholder="enterdate"
		value="<?php echo $pension; ?>" onfocus="this.value=''" required>
	</td>
	</tr>
	<tr><td>Basic Salary:</td>
		<td><input type="text" name = "basicsalary" style="width: 400px"
		value="<?php echo $basicsalary;?>" onfocus="this.value=''" required>
	</td></tr>
	<tr><td>Over Time:</td>
		<td><input type="text" name = "overtime" style="width: 400px"
		value="<?php echo $overtime;?>" onfocus="this.value=''" required>
	</td>
	</tr>
  </center>
</table>


<!--==================================================================================================================-->

	<table class="style1" > 
	<tr>
	    <center id="left">
		
				<tr>
				<td>Gross Pay:</td>
					<td><input type="text" name = "grosspay" style="width: 400px" 
					value="<?php echo $grosspay; ?>" onfocus="this.value=''">
					
				</td></tr>
				<tr><td>Deductions:</td>
					<td><input type="text" name = "deduction" style="width: 400px" 
					value="<?php echo $deduction; ?>" onfocus="this.value=''">
				</td></tr>

				<tr><td>Net Pay:</td>
					<td><input type="text" name = "netpay" style="width: 400px"
					value="<?php echo $netpay; ?>" onfocus="this.value=''">
				</td></tr>
				</center>
		</tr></table>

<!--====================================================================================================================-->

		 <center>
		 	<table>
				<tr>
				<td>&nbsp;</td><td align="left" style="width: 400px">
				<input type="submit" value="Submit" name = "add" class='btn'></td>	
				</tr>
				<tr>
				<td>&nbsp;</td><td align="left" style="width: 400px">
				<input type="reset" value="Reset" name ="cleartext" class='btn' onclick="reset();"></td> 		
				</tr>
				<tr>
				<td><a href="user_data_print.php"  onclick="window.print();"  align="left" style="width:400px" class='btn' id="btn1" >Print</a></td>
			</tr></table>
		</center>
		

<!--====================================================================================================================-->
</table>
</form>
</BODY>
</HTML>
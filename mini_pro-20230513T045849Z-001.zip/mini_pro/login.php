<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Employee's Payroll Management System</title>
  

<?php include('./header.php'); ?>
<?php include('./db_connect.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

?>

</head>
<style>
  body{
    width: 100%;
      height: calc(100%);
      /*background: #007bff;*/
          background: url(assets/img/1.png);
       
  }
  main#main{
    width:100%;
    height: 40%;
    background:pink;
                 margin-bottom:50px;
                padding-left: 35px;
  }
  #login-right{
    position: absolute;
    right:0;
                 margin:100px 50px 0px 180px;
    width:30%;
    height: 70%;
    background:orange;
    display: flex;
    align-items: center;
                border:2px solid blue;
                border-radius:5px;
  }
       #login-right:hover{
            border:3px solid #800080;
        }
  #login-left{
    position: absolute;
    left:0;
    width:90%;
    height: calc(100%);
    background:#59b6ec61;
    display: flex;
    align-items: center;
    background: url(assets/img/Payroll.png);
      background-repeat: no-repeat;
      background-size: cover;
  }
  #login-right .card{
    margin: auto;
    z-index: 1
  }
  .logo {
    margin: auto;
    font-size: 8rem;
    background: white;
    padding: .5em 0.7em;
    border-radius: 50% 50%;
    color: #000000b3;
    z-index: 10;
}
div#login-right::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: calc(100%);
    height: calc(100%);
    background:lightblue;
}
#head h1{
            color:  #ff0000;
        text-shadow:1px 1px  black;
        }
      #head h1 span{
        font-size:33px;
      }
        #head h2{
            color:orange;
         text-shadow:1px 1px black;
        }
      #head h2 span{
        font-size:32px;
      }
  .col-sm-8{
            margin-top:90px;
            width:40%;
            height: 80%;
            float:left;
            border:none;
            margin-left: 50px;
        }
        .col-sm-8 h2{
                  color:#3240a8;
                  text-shadow: 1px 1px black;
                  margin-left: 10px;
                 
        }
        .col-sm-8 p{
                color:white;
                font-size:20px;     
        }
  label{  
    color:#eb345e;  
    font-size: 17px;  
}  

</style>

<body>


  <main id="main">
                 <div id="head">   
            <center><img src="assets\img\logo1.png" align ="left" width="60px" height="60px" class="img" ></center>
           <h1 style="color:  #ff0000;
          text-shadow:1px 1px  black;">Rajiv Gandhi University of Knowledge Technologies <span style="color:orange;
           text-shadow:1px 1px black;">Srikakulam</span>
        </h1>
       </div>
      
                    <div class="col-sm-8">
                    <h2 >Payroll Management System</h2>
                    <p>Welcome to Online Payroll Management System of RGUKT, Srikakulam.</p><p>where adminstrate of sklm can be generate their corresponded employee playslip</p>
                   </div> 
        <div id="login-right">
        <div class="card col-md-8">
          <div class="card-body">
              
            <form id="login-form" >
              <div class="form-group">
                <label for="username" class="control-label">Username:</label>
                <input type="text" id="username" name="username" class="form-control" placeholder="username">
              </div>
              <div class="form-group">
                <label for="password" class="control-label">Password:</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="password">
              </div>
              <center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
            </form>
          </div>
        </div>
           </div>
              
   

  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
  $('#login-form').submit(function(e){
    e.preventDefault()
    $('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
    if($(this).find('.alert-danger').length > 0 )
      $(this).find('.alert-danger').remove();
    $.ajax({
      url:'ajax.php?action=login',
      method:'POST',
      data:$(this).serialize(),
      error:err=>{
        console.log(err)
    $('#login-form button[type="button"]').removeAttr('disabled').html('Login');

      },
      success:function(resp){
        if(resp == 1){
          location.href ='index.php?page=home';
        }else if(resp == 2){
          location.href ='voting.php';
        }else{
          $('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
          $('#login-form button[type="button"]').removeAttr('disabled').html('Login');
        }
      }
    })
  })
</script> 
</html>